# Viktor Smart Router

This is the ready-to-submit bundle for the Viktor Challenge. It contains the router, its reproducible offline evaluation, generated route decisions, the required six-policy comparison, and the five-slide HTML presentation.

## What to open first

- `presentation.html` — five-minute deck; use the left/right arrow keys.
- `results/required_baselines.svg` — the single comparison chart.
- `results/required_baselines.csv` — exact values behind the chart.
- `SUBMISSION.md` — methodology, caveats, and exact reproduction commands.

## Router behavior

The Smart Router makes one decision from the opening call. A score of at least 0.75 selects the cheaper model in the same provider family for the entire trajectory; otherwise it retains the logged model. “Zero switches” means zero changes *within* a trajectory, not zero reroutes: 15 complete trajectories are assigned a cheaper model.

## Included comparisons

The evaluation places all six required policies on the same cache-aware, estimated input-cost scale:

1. Observed/logged
2. Always cheapest
3. Always strongest
4. Random routing at Smart-matched cost
5. Viktor length heuristic
6. Smart opening gate

## Requirements

Python 3.10 or newer. Matplotlib is optional; the plotting script has a dependency-free fallback. No API key or GPU is required. Supply the challenge dataset separately and do not commit or redistribute it.

## Main result

The selected Smart policy estimates `$0.1126` input cost versus `$0.2524` logged cost, a `55.4%` reduction, at expected success `0.833`. These are observational off-policy estimates, not online experimental outcomes; see `SUBMISSION.md` for uncertainty and limitations.
